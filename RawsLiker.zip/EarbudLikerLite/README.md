# Earbud Liker (Lite)

Tap your earbud and the song playing in YouTube Music is liked. No Google account, no API, no internet permission.

It presses YouTube Music's own like control in the background (nothing happens on screen). You feel one vibration when it worked, two when it did not.

> Written without an Android SDK, so it has not been compiled or run. The GitHub build below will show any compile error in its log.

## Get the APK (no Android Studio needed)
1. Create a free account at github.com and a **new repository** (private is fine).
2. Click **uploading an existing file** and drag in the **contents** of this folder (including the hidden `.github` folder, so use the unzipped folder on a computer). Commit.
3. Open the **Actions** tab -> **Build APK** -> wait ~3 minutes for the green check.
4. Open the run, download **EarbudLiker-apk**, unzip it, and send `app-debug.apk` to your phone.
5. Install it (allow "install unknown apps" when asked).

## Use it
1. Open the app, tap **Grant** on each permission row. Notification access is the important one.
2. On Honor/Magic UI also go to Settings -> Battery -> App launch -> Earbud Liker -> **Manage manually**, all toggles on.
3. In the **Honor earbuds app**, set one gesture (e.g. triple tap) to **Previous track**.
4. Turn on **Listen for earbud taps**.
5. Play a song in YouTube Music and press **Test: like current song now** first.
6. Then try the earbud gesture.

## If it does not work
- **"No like button found"**: tap **Show what YouTube Music exposes** while a song plays and send me the text. I will adjust the matching.
- **Tap still skips the song**: Android sent the key to YouTube Music instead of this app. Send me your phone model and I will add the stronger workaround.
- After a reboot, open the app once.
- That gesture no longer skips tracks. It is now your like button.
- Pressing it on an already-liked song does nothing harmful (it reports "Already liked" instead of un-liking).
