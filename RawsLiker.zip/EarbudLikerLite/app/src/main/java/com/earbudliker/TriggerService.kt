package com.earbudliker

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.session.MediaController
import android.media.session.MediaSession
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Build
import android.os.IBinder
import android.os.VibrationEffect
import android.os.Vibrator
import android.support.v4.media.session.MediaSessionCompat
import android.support.v4.media.session.PlaybackStateCompat
import android.view.KeyEvent
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import java.text.DateFormat
import java.util.Date

/**
 * Foreground service that owns a MediaSession. Earbud taps arrive as media keys; the chosen
 * key presses "like" in YouTube Music, every other key is forwarded to the real player.
 */
class TriggerService : Service() {

    companion object {
        private const val CHANNEL = "service"
        private const val ACTION_RUN = "com.earbudliker.RUN"
        @Volatile var running = false
            private set

        fun start(ctx: Context) {
            ContextCompat.startForegroundService(ctx, Intent(ctx, TriggerService::class.java))
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, TriggerService::class.java))
        }

        /** Same as an earbud tap; used by the test button. */
        fun runNow(ctx: Context) {
            ContextCompat.startForegroundService(
                ctx, Intent(ctx, TriggerService::class.java).setAction(ACTION_RUN)
            )
        }
    }

    private lateinit var prefs: Prefs
    private lateinit var session: MediaSessionCompat
    private var sessionsRegistered = false
    private val watched = mutableMapOf<MediaSession.Token, Pair<MediaController, MediaController.Callback>>()

    private val sessionsListener =
        MediaSessionManager.OnActiveSessionsChangedListener { watch(it ?: emptyList()) }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        running = true
        prefs = Prefs(this)

        getSystemService(NotificationManager::class.java).createNotificationChannel(
            NotificationChannel(CHANNEL, "Listening for earbuds", NotificationManager.IMPORTANCE_LOW)
        )
        ServiceCompat.startForeground(
            this, 1, foregroundNotification(),
            if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK else 0
        )

        session = MediaSessionCompat(this, "EarbudLiker").apply {
            setCallback(object : MediaSessionCompat.Callback() {
                override fun onMediaButtonEvent(mediaButtonEvent: Intent): Boolean =
                    handleKey(mediaButtonEvent)
            })
            isActive = true
        }
        claimMediaButtons()
        registerSessions()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        registerSessions() // retry in case notification access was granted after start
        if (intent?.action == ACTION_RUN) likeNow()
        return START_STICKY
    }

    override fun onDestroy() {
        running = false
        try {
            getSystemService(MediaSessionManager::class.java)
                .removeOnActiveSessionsChangedListener(sessionsListener)
        } catch (_: Exception) {
        }
        watched.values.forEach { (c, cb) -> c.unregisterCallback(cb) }
        watched.clear()
        session.release()
        super.onDestroy()
    }

    private fun foregroundNotification(): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("Earbud Liker is listening")
            .setContentText("Tap your earbud to like the current song")
            .setOngoing(true)
            .setContentIntent(open)
            .build()
    }

    // ---- media key handling ---------------------------------------------

    private fun handleKey(intent: Intent): Boolean {
        @Suppress("DEPRECATION")
        val event: KeyEvent = (if (Build.VERSION.SDK_INT >= 33)
            intent.getParcelableExtra(Intent.EXTRA_KEY_EVENT, KeyEvent::class.java)
        else
            intent.getParcelableExtra<KeyEvent>(Intent.EXTRA_KEY_EVENT)) ?: return false

        if (event.keyCode == prefs.triggerKey.keyCode) {
            if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) likeNow()
            return true
        }
        // Not ours: hand it to the real player (play/pause, next, ...)
        NowPlaying.target(this)?.dispatchMediaButtonEvent(event)
        return true
    }

    /**
     * Android sends media keys to the most recently "playing" session. Toggling our session
     * paused -> playing puts it on top; repeated whenever another player changes state.
     */
    private fun claimMediaButtons() {
        val actions = PlaybackStateCompat.ACTION_PLAY or PlaybackStateCompat.ACTION_PAUSE or
            PlaybackStateCompat.ACTION_PLAY_PAUSE or PlaybackStateCompat.ACTION_SKIP_TO_NEXT or
            PlaybackStateCompat.ACTION_SKIP_TO_PREVIOUS
        fun state(s: Int) = PlaybackStateCompat.Builder().setActions(actions).setState(s, 0L, 0f).build()
        session.setPlaybackState(state(PlaybackStateCompat.STATE_PAUSED))
        session.setPlaybackState(state(PlaybackStateCompat.STATE_PLAYING))
    }

    private fun registerSessions() {
        if (sessionsRegistered) return
        try {
            val msm = getSystemService(MediaSessionManager::class.java)
            val component = NowPlaying.listener(this)
            msm.addOnActiveSessionsChangedListener(sessionsListener, component)
            sessionsRegistered = true
            watch(msm.getActiveSessions(component))
        } catch (_: SecurityException) {
            // Notification access not granted yet
        }
    }

    private fun watch(list: List<MediaController>) {
        val current = list.filter { it.packageName != packageName }
        val currentTokens = current.map { it.sessionToken }.toSet()

        watched.keys.filter { it !in currentTokens }.forEach { token ->
            watched.remove(token)?.let { (c, cb) -> c.unregisterCallback(cb) }
        }
        current.forEach { c ->
            if (c.sessionToken !in watched) {
                val cb = object : MediaController.Callback() {
                    override fun onPlaybackStateChanged(state: PlaybackState?) = claimMediaButtons()
                }
                c.registerCallback(cb)
                watched[c.sessionToken] = c to cb
            }
        }
        claimMediaButtons()
    }

    // ---- the like --------------------------------------------------------

    private fun likeNow() {
        val controller = NowPlaying.target(this)
        val message: String
        var success = false
        if (controller == null) {
            message = if (NowPlaying.hasAccess(this)) "Nothing is playing"
            else "Notification access is off. Enable it in the app"
        } else {
            val song = NowPlaying.title(controller)
            message = try {
                when (Liker.like(controller)) {
                    Outcome.LIKED -> { success = true; "Liked: $song" }
                    Outcome.ALREADY_LIKED -> { success = true; "Already liked: $song" }
                    Outcome.NOT_FOUND -> "No like button found for: $song (see Diagnostics in the app)"
                }
            } catch (e: Exception) {
                "Failed: ${e.message ?: e.javaClass.simpleName}"
            }
        }
        val time = DateFormat.getTimeInstance(DateFormat.SHORT).format(Date())
        prefs.lastResult = "$time  $message"
        buzz(if (success) 1 else 2)
    }

    /** One short buzz = done, two = problem. Handy when the phone is in your pocket. */
    private fun buzz(times: Int) {
        val v = getSystemService(Vibrator::class.java) ?: return
        val pattern = if (times == 1) longArrayOf(0, 60) else longArrayOf(0, 60, 80, 60, 80, 60)
        v.vibrate(VibrationEffect.createWaveform(pattern, -1))
    }
}
