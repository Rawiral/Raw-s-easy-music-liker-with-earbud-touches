package com.earbudliker

import android.service.notification.NotificationListenerService

/**
 * Enabling this in Settings > Notification access lets the app (1) see other apps' media
 * sessions and (2) read the buttons on YouTube Music's player notification.
 */
class MediaListener : NotificationListenerService() {
    companion object {
        @Volatile var instance: MediaListener? = null
            private set
    }

    override fun onListenerConnected() {
        instance = this
    }

    override fun onListenerDisconnected() {
        if (instance === this) instance = null
    }
}
