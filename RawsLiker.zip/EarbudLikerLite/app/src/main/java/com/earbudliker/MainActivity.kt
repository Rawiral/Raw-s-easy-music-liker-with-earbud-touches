package com.earbudliker

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {

    private lateinit var prefs: Prefs

    // Bumped in onResume so permission states are re-read after returning from Settings
    private var tick by mutableStateOf(0)
    private var serviceOn by mutableStateOf(false)
    private var trigger by mutableStateOf(TriggerKey.PREVIOUS)
    private var diagnostics by mutableStateOf("")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        serviceOn = prefs.serviceEnabled
        trigger = prefs.triggerKey
        setContent {
            MaterialTheme {
                Surface(Modifier.fillMaxSize()) { Screen() }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        tick++
        // The system may have killed the service; bring it back when the app is opened
        if (prefs.serviceEnabled && !TriggerService.running) TriggerService.start(this)
    }

    private fun runDiagnostics() {
        val c = NowPlaying.target(this)
        diagnostics = when {
            !NowPlaying.hasAccess(this) -> "Notification access is off."
            c == null -> "No player found. Start a song in YouTube Music first."
            else -> Liker.describe(c)
        }
    }

    @Composable
    private fun Screen() {
        val listenerOn = remember(tick) { NowPlaying.hasAccess(this) }
        val notifOk = remember(tick) {
            Build.VERSION.SDK_INT < 33 ||
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        }
        val batteryOk = remember(tick) {
            getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(packageName)
        }
        val last = remember(tick) { prefs.lastResult }
        val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { tick++ }

        Column(
            Modifier
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("Earbud Liker", style = MaterialTheme.typography.headlineMedium)
            Text("Tap your earbud to like the song playing in YouTube Music. No account needed.")

            Section("1. Permissions") {
                PermissionRow("Notification access (required)", listenerOn) {
                    startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                }
                if (Build.VERSION.SDK_INT >= 33) {
                    PermissionRow("Show notifications", notifOk) {
                        notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                    }
                }
                PermissionRow("Ignore battery optimization", batteryOk) {
                    startActivity(
                        Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                            .setData(Uri.parse("package:$packageName"))
                    )
                }
            }

            Section("2. Earbud gesture") {
                Text("In the Honor earbuds app, set one gesture (e.g. triple tap) to:")
                TriggerKey.values().forEach { key ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = trigger == key, onClick = { trigger = key; prefs.triggerKey = key })
                        Text(key.label)
                    }
                }
                Text("That gesture will like instead of skipping.", style = MaterialTheme.typography.bodySmall)
            }

            Section("3. Run") {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("Listen for earbud taps", Modifier.weight(1f))
                    Switch(checked = serviceOn, onCheckedChange = { on ->
                        serviceOn = on
                        prefs.serviceEnabled = on
                        if (on) TriggerService.start(this@MainActivity) else TriggerService.stop(this@MainActivity)
                    })
                }
                OutlinedButton(onClick = { TriggerService.runNow(this@MainActivity) }) {
                    Text("Test: like current song now")
                }
                if (last.isNotEmpty()) Text("Last: $last", style = MaterialTheme.typography.bodySmall)
            }

            Section("Diagnostics") {
                Text(
                    "If the test says no like button was found, tap this while a song plays and send me the text.",
                    style = MaterialTheme.typography.bodySmall
                )
                Button(onClick = { runDiagnostics() }) { Text("Show what YouTube Music exposes") }
                if (diagnostics.isNotEmpty()) SelectionContainer { Text(diagnostics) }
            }
        }
    }

    @Composable
    private fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(title, style = MaterialTheme.typography.titleMedium)
                content()
            }
        }
    }

    @Composable
    private fun PermissionRow(label: String, granted: Boolean, onGrant: () -> Unit) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(label, Modifier.weight(1f))
            if (granted) Text("OK") else Button(onClick = onGrant) { Text("Grant") }
        }
    }
}
