package com.earbudliker

import android.content.ComponentName
import android.content.Context
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import androidx.core.app.NotificationManagerCompat

/** Finds the player we act on, using media sessions. */
object NowPlaying {
    const val YT_MUSIC = "com.google.android.apps.youtube.music"

    fun listener(context: Context) = ComponentName(context, MediaListener::class.java)

    fun hasAccess(context: Context): Boolean =
        NotificationManagerCompat.getEnabledListenerPackages(context).contains(context.packageName)

    fun controllers(context: Context): List<MediaController> {
        val msm = context.getSystemService(MediaSessionManager::class.java)
        return try {
            msm.getActiveSessions(listener(context)).filter { it.packageName != context.packageName }
        } catch (e: SecurityException) {
            emptyList()
        }
    }

    /** YouTube Music if it has a session, else whatever is playing. */
    fun target(context: Context): MediaController? {
        val all = controllers(context)
        return all.firstOrNull { it.packageName == YT_MUSIC }
            ?: all.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
    }

    fun title(c: MediaController): String {
        val m = c.metadata ?: return "current song"
        val t = m.getString(MediaMetadata.METADATA_KEY_TITLE) ?: return "current song"
        val a = m.getString(MediaMetadata.METADATA_KEY_ARTIST)
        return if (a.isNullOrBlank()) t else "$a – $t"
    }
}
