package com.earbudliker

import android.content.Context
import android.view.KeyEvent

/** Which earbud media key triggers the like. */
enum class TriggerKey(val keyCode: Int, val label: String) {
    PREVIOUS(KeyEvent.KEYCODE_MEDIA_PREVIOUS, "Previous track"),
    NEXT(KeyEvent.KEYCODE_MEDIA_NEXT, "Next track")
}

class Prefs(context: Context) {
    private val sp = context.applicationContext.getSharedPreferences("settings", Context.MODE_PRIVATE)

    var triggerKey: TriggerKey
        get() = runCatching { TriggerKey.valueOf(sp.getString("triggerKey", "PREVIOUS")!!) }
            .getOrDefault(TriggerKey.PREVIOUS)
        set(v) { sp.edit().putString("triggerKey", v.name).apply() }

    var serviceEnabled: Boolean
        get() = sp.getBoolean("serviceEnabled", false)
        set(v) { sp.edit().putBoolean("serviceEnabled", v).apply() }

    var lastResult: String
        get() = sp.getString("lastResult", "") ?: ""
        set(v) { sp.edit().putString("lastResult", v).apply() }
}
