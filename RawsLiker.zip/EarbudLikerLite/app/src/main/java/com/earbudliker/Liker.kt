package com.earbudliker

import android.media.MediaMetadata
import android.media.Rating
import android.media.session.MediaController
import java.util.Locale

enum class Outcome { LIKED, ALREADY_LIKED, NOT_FOUND }

/**
 * Presses the player's own "like" control without touching the screen.
 * Tries, in order: the media session's custom actions, the buttons on the player's
 * notification, then the standard thumbs-up rating. Works in English and Turkish.
 */
object Liker {

    // Labels that mean "press to like"
    private val LIKE_WORDS = listOf("like", "thumb", "beğen", "begen", "favori")

    // Labels that mean "already liked" (press to remove) or something we must not press
    private val ALREADY_WORDS = listOf("unlike", "liked", "remove", "beğenme", "beğenildi", "beğenmeyi", "kaldır")
    private val NEVER_WORDS = listOf("dislike", "thumbs down", "thumb down", "beğenmedim")

    private fun norm(s: String) = s.lowercase(Locale.ROOT)

    private fun isAlready(label: String): Boolean {
        val t = norm(label)
        return NEVER_WORDS.none { t.contains(it) } && ALREADY_WORDS.any { t.contains(it) }
    }

    private fun isLike(label: String): Boolean {
        val t = norm(label)
        return NEVER_WORDS.none { t.contains(it) } &&
            ALREADY_WORDS.none { t.contains(it) } &&
            LIKE_WORDS.any { t.contains(it) }
    }

    fun like(c: MediaController): Outcome {
        var sawAlready = false

        // 1) custom actions on the media session
        val actions = c.playbackState?.customActions.orEmpty()
        actions.firstOrNull { isLike("${it.name} ${it.action}") }?.let {
            c.transportControls.sendCustomAction(it.action, it.extras)
            return Outcome.LIKED
        }
        if (actions.any { isAlready("${it.name} ${it.action}") }) sawAlready = true

        // 2) buttons on the player's notification
        val notificationActions = notificationActions(c.packageName)
        notificationActions.firstOrNull { isLike(it.title?.toString().orEmpty()) }?.let {
            it.actionIntent?.send()
            return Outcome.LIKED
        }
        if (notificationActions.any { isAlready(it.title?.toString().orEmpty()) }) sawAlready = true

        // 3) standard thumbs-up rating, if the player supports it
        val meta = c.metadata
        if (meta != null && meta.containsKey(MediaMetadata.METADATA_KEY_USER_RATING)) {
            val current = meta.getRating(MediaMetadata.METADATA_KEY_USER_RATING)
            if (current != null && current.isRated && current.isThumbUp) return Outcome.ALREADY_LIKED
            c.transportControls.setRating(Rating.newThumbRating(true))
            return Outcome.LIKED
        }

        return if (sawAlready) Outcome.ALREADY_LIKED else Outcome.NOT_FOUND
    }

    private fun notificationActions(pkg: String): List<android.app.Notification.Action> =
        runCatching {
            MediaListener.instance?.activeNotifications.orEmpty()
                .filter { it.packageName == pkg }
                .flatMap { it.notification.actions?.toList().orEmpty() }
        }.getOrDefault(emptyList())

    /** Plain-text dump of what the player exposes. Shown in the app for troubleshooting. */
    fun describe(c: MediaController): String {
        val sb = StringBuilder()
        sb.appendLine("Player: ${c.packageName}")
        sb.appendLine("Song: ${NowPlaying.title(c)}")
        sb.appendLine("Custom actions:")
        val actions = c.playbackState?.customActions.orEmpty()
        if (actions.isEmpty()) sb.appendLine("  (none)")
        actions.forEach { sb.appendLine("  \"${it.name}\"  id=${it.action}") }
        sb.appendLine("Notification buttons:")
        val na = notificationActions(c.packageName)
        if (na.isEmpty()) sb.appendLine("  (none)")
        na.forEach { sb.appendLine("  \"${it.title}\"") }
        sb.appendLine(
            "Thumb rating supported: " +
                (c.metadata?.containsKey(MediaMetadata.METADATA_KEY_USER_RATING) == true)
        )
        return sb.toString()
    }
}
